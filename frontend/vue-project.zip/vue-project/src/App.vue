<template>
  <test />
  <br />
  <div>HelloWorld</div>
</template>

<script>
import test from "@/components/test.vue";
export default {
  components: {
    test,
  },
};
</script>

<style scoped></style>
